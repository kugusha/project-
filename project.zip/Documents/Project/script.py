from instagram.client import InstagramAPI

access_token = '33381451.7881c41.a847da031c694288a265ccb24234fcd6'
client_secret = "787f48c0419945d58c0e658e9f8ea9be"

api = InstagramAPI(access_token=access_token, client_secret=client_secret)

x = api.user_media_feed()
# for media in recent_media:
#    print recent_media
