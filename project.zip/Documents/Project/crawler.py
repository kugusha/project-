import pymongo 
import vk
import re
# connect to mongo, get 'users' collection
# loop into users
# check 'website', if 'website' == 'vk.com/...' - OK
# in this case, save user to 'usersVK'
client = pymongo.MongoClient()

VK_access_token = '0c46a2d259476ff66b1616b27184a42b7b76371b0e13b7e9092a22fb2112ba2559349d5878e8ae278c2f9'
session = vk.Session(access_token = VK_access_token)
api = vk.API(session)

users = client["users"]["users"]
usersVK = client["users"]["usersVK"]
p = re.compile('https://www.vk.com/')
pattern = 'https://www.vk.com/'

for user in users.find():
	# print "USERNAME: {}, WEBSITE: {}".format(user['username'], user['website'] or 'None')
	# p = re.compile('vk.com/')
	if pattern in user['website']:
		print "OK"


# https://oauth.vk.com/authorize?client_id=5329723&display=page&redirect_uri=https://yandex.ru/redirect&scope=friends&response_type=token&v=5.45
