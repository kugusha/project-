import json
import pymongo

with open('trvl.json') as dataFile:
	data = json.load(dataFile)

for i in data:
	print i, data[i]
	break